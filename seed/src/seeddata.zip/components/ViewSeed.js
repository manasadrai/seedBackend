import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom';
import * as actionCreated from '../actions/actions'

class ViewSeed extends Component {

    componentDidMount() {
        this.props.onGetSeeds()
    }

    delete(id) {
        this.props.onDeleteSeed(id);
    }
    updateClick(seedsList){
     //   console.log("check",seedsList,this.props.history)
        this.props.history.push({
            pathname:"/add",state:{seedsList}
        })
    }

    
    render() {

        console.log(this.props)
        let seedsList = this.props.seedsList.map((seed, index) => {
            
            return (
                <tr key={index}>
                   <th>{seed.seedId}</th>
                    <td>{seed.commonName}</td>
                    <td>{seed.bloomTime}</td>
                    <td>{seed.watering}</td>
                    <td>{seed.difficultyLevel}</td>
                    <td>{seed.temperature}</td>
                    <td>{seed.typeOfSeeds}</td>
                    <td>{seed.seedDescription}</td>
                    <td>{seed.seedStock}</td>
                    <td>{seed.seedCost}</td>
                    <td>{seed.seedsPerPacket}</td>
                    <td>
                        <button onClick={this.delete.bind(this, seed.seedId)} className="btn btn-primary">DELETE</button>
                    </td>
                    <td>
                        <button onClick={this.updateClick.bind(this,seed)} className="btn btn-primary">UPDATE</button>
                    </td>
                </tr>
            )
        })

        var tableStyle = {
            "border": "1px solid black"
         };
        return (
            <div className="seed-table-div">

                <h2>*******SEED DETAILS********</h2>

                <table className="table table-info seed-table" style={tableStyle}>
                    <thead>
                        <tr>
                        <th scope="col">Seed Id</th>
                        <th scope="col">BloomTime</th>
                        <th scope="col">Watering</th>
                        <th scope="col">Difficulty Level</th>
                        <th scope="col">Temperature</th>
                        <th scope="col">Type Of Seeds</th>
                        <th scope="col">Seed Description</th>
                        <th scope="col">Seed Stock</th>
                        <th scope="col">Seed Cost</th>
                        <th scope="col">Seeds Per Packet</th>
                        <th>Delete</th>
                        <th>UPDATE</th>
                        </tr>
                    </thead>
                    <tbody>
                        {seedsList}
                    </tbody>
                </table>

            </div>
        )
    }

}

const mapStateToProps = (state) => {
    return {
        seedsList: state.seedsList,
        returnedMessage: state.returnedMessage
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onGetSeeds: () => {
            return dispatch(actionCreated.getAllSeeds())
        },
        onDeleteSeed: (id) => {
            return dispatch(actionCreated.deleteSeed(id))
        },
        clearState: () => {
            return dispatch(actionCreated.clearState())
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(ViewSeed))
